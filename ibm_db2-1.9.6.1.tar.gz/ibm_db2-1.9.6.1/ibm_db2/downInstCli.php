<?php
$url = $argv[1];
$fileName = $argv[2];
$extPath = $argv[3];
$ptf = $argv[4];
$fd = fopen($url, "r");


if ($data = fread($fd, 1024)) {
    $wp = @fopen($fileName, 'wb');
    fwrite($wp, $data);
} else {
    return;
}
while ($data = fread($fd, 1024)) {
    if (!@fwrite($wp, $data)) {
        fclose($fp);
    }
}
fclose($wp);

#echo $fileName;
if (file_exists($fileName)) {
    if ($ptf == "Linux") {
        exec("tar -zxvf ".$fileName." -C ".$extPath);
        return;
    } else {
        print("\nAuto installation of DS driver is not enabled for this platform, Please install and set IBM_DB_HOME to your DB2/IBM_Data_Server_Driver installation directory and retry ibm_db2 module install");
        return;
    }
} else {
    print('\nFile does not exist');
    return;
}
?>