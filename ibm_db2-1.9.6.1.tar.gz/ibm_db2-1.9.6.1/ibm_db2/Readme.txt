version ibm_db2 =  1.9.6.1

## Original config install ##

wget https://public.dhe.ibm.com/ibmdl/export/pub/software/data/db2/drivers/odbc_cli/ibm_db2-1.9.6.1.tar
tar -xvf ibm_db2-1.9.6.1.tar
mv ibm_db2-1.9.6.1/ ibm_db2/ 
cd /home/cobalto/ibm_db2/

wget https://public.dhe.ibm.com/ibmdl/export/pub/software/data/db2/drivers/odbc_cli/v11.1.4/linuxx64_odbc_cli.tar.gz
tar zxvf linuxx64_odbc_cli.tar.gz 
cd /home/cobalto/ibm_db2/

phpize --clean
phpize
./configure --with-IBM_DB2=/home/cobalto/ibm_db2/clidriver/
make && make install 

export IBM_DB_HOME=/home/cobalto/ibm_db2/clidriver
export LD_LIBRARY_PATH=/home/cobalto/ibm_db2/clidriver/lib
export PATH=/home/cobalto/ibm_db2/clidriver/bin:$PATH
